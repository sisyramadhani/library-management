import ReturnRequest from '../components/ReturnRequest';

const Returns = () => {
  return <ReturnRequest />;
};

export default Returns;