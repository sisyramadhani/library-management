import BookList from '../components/BookList';

const Books = () => {
  return <BookList />;
};

export default Books;